some shell scripts I put in my router's $PATH. I call him SlayerWRT.

that's mostly so my scripts are in the cloud, and I don't lose my work in case things go south.
