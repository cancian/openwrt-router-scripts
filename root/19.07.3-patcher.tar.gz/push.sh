cp 01_leds        target/linux/ramips/base-files/etc/board.d/
cp 02_network     target/linux/ramips/base-files/etc/board.d/y
cp mt7620.mk      target/linux/ramips/image/
cp ArcherC5v4.dts target/linux/ramips/dts/ArcherC5v4.dts/
